from app.repositories.my_application_repository import (
    MyApplicationRepository,
)
from app.schemas.my_applications import (
    MyApplicationsResponse,
    MyClubApplicationItemResponse,
    MyGuestApplicationItemResponse,
)


class MyApplicationService:

    def __init__(self):
        self.repository = MyApplicationRepository()

    # -----------------------------------------------------
    # 동호회 가입 신청
    #
    # 같은 동호회에 여러 번 신청했으면 가장 최근 신청만 보여준다.
    # -----------------------------------------------------
    def collect_club_applications(
        self,
        user_id: str,
    ) -> list[MyClubApplicationItemResponse]:

        rows = (
            self.repository
            .find_club_applications_by_user(user_id)
        )

        # 최신순으로 받았으므로 동호회마다 첫 번째만
        latest_rows = []
        seen_club_ids: set[int] = set()

        for row in rows:
            club_id = int(row["club_id"])

            if club_id in seen_club_ids:
                continue

            seen_club_ids.add(club_id)
            latest_rows.append(row)

        if not latest_rows:
            return []

        club_ids = list(seen_club_ids)

        club_name_by_id = (
            self.repository.find_club_names_by_ids(club_ids)
        )

        image_by_club_id = (
            self.repository
            .find_representative_images_by_club_ids(club_ids)
        )

        active_club_ids = (
            self.repository
            .find_active_club_ids_by_user(user_id)
        )

        return [
            MyClubApplicationItemResponse(
                application_id=int(row["application_id"]),
                club_id=int(row["club_id"]),
                club_name=club_name_by_id.get(
                    int(row["club_id"]),
                    "알 수 없는 동호회",
                ),
                club_image_url=image_by_club_id.get(
                    int(row["club_id"])
                ),
                status=row.get("status") or "pending",
                is_active_member=(
                    int(row["club_id"]) in active_club_ids
                ),
                created_at=row.get("created_at"),
                decided_at=row.get("decided_at"),
            )
            for row in latest_rows
        ]

    # -----------------------------------------------------
    # 게스트 신청
    #
    # 같은 일정에 여러 번 신청했으면 가장 최근 신청만 보여준다.
    # 정렬: 일정 날짜 최신순
    # -----------------------------------------------------
    def collect_guest_applications(
        self,
        user_id: str,
    ) -> list[MyGuestApplicationItemResponse]:

        rows = (
            self.repository
            .find_guest_applications_by_user(user_id)
        )

        latest_by_event: dict[int, dict] = {}

        for row in rows:
            event_id = int(row["event_id"])

            if event_id not in latest_by_event:
                latest_by_event[event_id] = row

        if not latest_by_event:
            return []

        event_rows = self.repository.find_events_by_ids(
            list(latest_by_event.keys())
        )

        club_name_by_id = self.repository.find_club_names_by_ids(
            list({
                int(event["club_id"])
                for event in event_rows
                if event.get("club_id") is not None
            })
        )

        event_rows.sort(
            key=lambda event: (
                str(event.get("event_date", "")),
                str(event.get("start_time", "") or ""),
            ),
            reverse=True,
        )

        items = []

        for event in event_rows:
            event_id = int(event["event_id"])
            club_id = int(event["club_id"])
            participant = latest_by_event[event_id]

            deadline = event.get("registration_deadline")

            items.append(
                MyGuestApplicationItemResponse(
                    event_participant_id=int(
                        participant["event_participant_id"]
                    ),
                    event_id=event_id,
                    club_id=club_id,
                    club_name=club_name_by_id.get(
                        club_id,
                        "알 수 없는 동호회",
                    ),
                    title=event.get("title") or "게스트 일정",
                    description=event.get("description"),
                    event_date=event["event_date"],
                    start_time=event["start_time"],
                    end_time=event.get("end_time"),
                    location=event.get("location"),
                    event_image_url=event.get("event_image_url"),
                    max_guests=event.get("max_guests"),
                    registration_deadline=(
                        str(deadline) if deadline else None
                    ),
                    event_status=event.get("status") or "open",
                    guest_status=participant.get("status") or "pending",
                )
            )

        return items

    # -----------------------------------------------------
    # 신청 현황 전체
    # -----------------------------------------------------
    def get_my_applications(
        self,
        user_id: str,
    ) -> MyApplicationsResponse:

        return MyApplicationsResponse(
            club_applications=self.collect_club_applications(user_id),
            guest_applications=self.collect_guest_applications(user_id),
        )
