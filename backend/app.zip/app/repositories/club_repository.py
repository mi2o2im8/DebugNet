from typing import List, Optional

from datetime import (
    date,
    datetime,
    time,
    timezone,
)
from zoneinfo import ZoneInfo

from app.core.supabase import get_supabase_admin_client


# ---------------------------------------------------------
# 동호회 관련 Supabase 작업을 담당하는 Repository
# ---------------------------------------------------------
class ClubRepository:

    def __init__(self):
        self.supabase = get_supabase_admin_client()
        self.admin_client = self.supabase

    # -----------------------------------------------------
    # 동호회 검색
    # -----------------------------------------------------
    def search_clubs(
        self,
        keyword: Optional[str] = None,
        sport_name: Optional[List[str]] = None,
        region: Optional[List[str]] = None,
        day_of_week: Optional[List[str]] = None,
        time_slot: Optional[List[str]] = None,
        atmosphere: Optional[str] = None,
    ):
        params = {
            "p_keyword": keyword,
            "p_sport_name": sport_name,
            "p_region": region,
            "p_day_of_week": day_of_week,
            "p_time_slot": time_slot,
            "p_atmosphere": atmosphere,
        }

        response = self.supabase.rpc(
            "search_clubs",
            params,
        ).execute()

        return response.data

    # -----------------------------------------------------
    # 동호회 상세 조회
    # -----------------------------------------------------
    def get_club_by_id(self, club_id: int):

        # 1. 동호회 기본 정보
        club_response = (
            self.supabase
            .table("clubs")
            .select("*")
            .eq("club_id", club_id)
            .single()
            .execute()
        )

        club = club_response.data

        if not club:
            return None

        # 2. 운동 종목 조회
        club_sports_response = (
            self.supabase
            .table("club_sports")
            .select("sport_id")
            .eq("club_id", club_id)
            .execute()
        )

        sport_ids = [
            item["sport_id"]
            for item in club_sports_response.data
        ]

        sports = []

        if sport_ids:
            sports_response = (
                self.supabase
                .table("sports")
                .select("sport_name")
                .in_("sport_id", sport_ids)
                .execute()
            )

            sports = [
                item["sport_name"]
                for item in sports_response.data
            ]

        # 3. 활동 지역 조회
        regions_response = (
            self.supabase
            .table("club_regions")
            .select("region")
            .eq("club_id", club_id)
            .execute()
        )

        regions = [
            item["region"]
            for item in regions_response.data
        ]

        # 4. 활동 시간 조회
        schedules_response = (
            self.supabase
            .table("club_schedules")
            .select(
                "day_of_week, start_time, end_time"
            )
            .eq("club_id", club_id)
            .execute()
        )

        schedules = schedules_response.data

        # 5. 동호회 분위기 조회
        atmospheres_response = (
            self.supabase
            .table("club_atmospheres")
            .select("atmosphere")
            .eq("club_id", club_id)
            .execute()
        )

        atmospheres = [
            item["atmosphere"]
            for item in atmospheres_response.data
        ]

        # 6. 동호회 이미지 조회
        images_response = (
            self.supabase
            .table("club_images")
            .select(
                "image_url, display_order, image_type"
            )
            .eq("club_id", club_id)
            .order("display_order")
            .execute()
        )

        images = images_response.data

        # 7. 상세 정보 추가
        club["sports"] = sports
        club["regions"] = regions
        club["schedules"] = schedules
        club["atmospheres"] = atmospheres
        club["images"] = images

        return club
    # ---------------------------------------------------------
    # ---------------------------------------------------------
    # 내가 운영 중인 동호회 + 가입한 동호회 조회
    # ---------------------------------------------------------
    def get_my_club(self, user_id: str):

        member_response = (
            self.supabase
            .table("club_members")
            .select(
                "club_id, role, status, joined_at"
            )
            .eq("user_id", user_id)
            .eq("status", "active")
            .order("joined_at", desc=True)
            .execute()
        )

        members = member_response.data or []

        result = {
            "operating_club": None,
            "operating_clubs": [],
            "joined_club": None,
            "joined_clubs": [],
        }

        for member in members:

            club_id = member["club_id"]

            club_response = (
                self.supabase
                .table("clubs")
                .select("*")
                .eq("club_id", club_id)
                .single()
                .execute()
            )

            club = club_response.data

            if (
                not club
                or club.get("status") is not True
            ):
                continue

            # ⭐ 종목명 조회
            sport_name = None

            club_sports_response = (
                self.supabase
                .table("club_sports")
                .select("sport_id")
                .eq("club_id", club_id)
                .limit(1)
                .execute()
            )

            if club_sports_response.data:

                sport_id = club_sports_response.data[0][
                    "sport_id"
                ]

                sport_response = (
                    self.supabase
                    .table("sports")
                    .select("sport_name")
                    .eq("sport_id", sport_id)
                    .single()
                    .execute()
                )

                if sport_response.data:
                    sport_name = sport_response.data[
                        "sport_name"
                    ]

            # =================================================
            # ⭐ 동호회 대표 이미지 조회
            #
            # 동호회 생성 API에서
            # image_type = "representative"
            # 로 저장하고 있으므로 동일한 값으로 조회
            # =================================================
            image_response = (
                self.supabase
                .table("club_images")
                .select(
                    "image_url, image_type, display_order"
                )
                .eq("club_id", club_id)
                .order(
                    "display_order",
                    desc=False,
                )
                .execute()
            )

            images = image_response.data or []

            representative_image = next(
                (
                    image
                    for image in images
                    if image.get("image_type")
                    == "representative"
                    and image.get("image_url")
                ),
                None,
            )

            # ⭐ 대표 이미지가 없으면 첫 이미지 사용
            if representative_image is None:
                representative_image = next(
                    (
                        image
                        for image in images
                        if image.get("image_url")
                    ),
                    None,
                )

            # =================================================
            # ⭐ 실제 활동 중인 회원 수
            #
            # clubs.current_members 값이 갱신되지 않은 경우에도
            # club_members의 active 행을 기준으로 표시
            # =================================================
            member_count_response = (
                self.admin_client
                .table("club_members")
                .select(
                    "club_member_id",
                    count="exact",
                )
                .eq("club_id", club_id)
                .eq("status", "active")
                .execute()
            )

            current_members = (
                member_count_response.count
                if member_count_response.count is not None
                else 0
            )

            club["sport_name"] = sport_name
            club["member_role"] = member.get("role")
            club["member_status"] = member.get("status")
            club["joined_at"] = member.get("joined_at")

            # ⭐ MainHome에서 바로 사용할 데이터
            club["representative_image_url"] = (
                representative_image.get("image_url")
                if representative_image
                else None
            )

            club["current_members"] = current_members

            # =================================================
            # ⭐ 운영 중인 동호회
            # =================================================
            if member.get("role") in [
                "owner",
                "manager",
                "동호회장",
                "운영진",
            ]:

                # ⭐ 운영 중인 동호회는 전부 저장
                result["operating_clubs"].append(club)

                # ⭐ 기존 코드와의 호환을 위해 첫 번째 운영 동호회 유지
                if result["operating_club"] is None:
                    result["operating_club"] = club

            # =================================================
            # ⭐ 일반 가입 동호회
            # =================================================
            elif member.get("role") in [
                "member",
                "회원",
            ]:

                # 같은 동호회 중복 방지
                existing_ids = {
                    item.get("club_id")
                    for item in result["joined_clubs"]
                }

                if club_id not in existing_ids:
                    result["joined_clubs"].append(club)

        # ⭐ 기존 joined_club 응답도 유지
        # 기존 화면/코드와의 호환을 위해 첫 번째 가입 동호회 전달
        if result["joined_clubs"]:
            result["joined_club"] = result[
                "joined_clubs"
            ][0]

        return result

    # -----------------------------------------------------
    # 동호회 가입 신청
    # -----------------------------------------------------
    def create_join_request(
        self,
        club_id: int,
        user_id: str,
    ):
        data = {
            "club_id": club_id,
            "user_id": user_id,
            "role": "member",
            "status": "pending",
            "join_source": "club_detail",
        }

        response = (
            self.supabase
            .table("club_members")
            .insert(data)
            .execute()
        )

        return response.data

    # -----------------------------------------------------
    # 동호회 가입 상태 조회
    # -----------------------------------------------------
    def get_member_status(
        self,
        club_id: int,
        user_id: str,
    ):
        # 1. 정식 회원인지 확인
        member_response = (
            self.supabase
            .table("club_members")
            .select("status")
            .eq("club_id", club_id)
            .eq("user_id", user_id)
            .limit(1)
            .execute()
        )

        if member_response.data:
            member_status = member_response.data[0]["status"]

            # 현재 정식 회원이면 가입 완료
            if member_status == "active":
                return "active"

            # 탈퇴한 회원이면 기존 탈퇴 이력을 유지하면서
            # 다시 가입 신청할 수 있도록 아래의 신청 상태를 확인한다.
            if member_status == "withdrawn":
                pass

            # 그 외 회원 상태가 있다면 기존 상태 반환
            else:
                return member_status

        # 2. 가입 신청 상태 확인
        application_response = (
            self.supabase
            .table("club_applications")
            .select("status")
            .eq("club_id", club_id)
            .eq("user_id", user_id)
            .order("created_at", desc=True)
            .limit(1)
            .execute()
        )

        if application_response.data:
            application_status = application_response.data[0]["status"]

            # 현재 가입 신청이 승인 대기 중
            if application_status == "pending":
                return "pending"

            # 최근 신청 상태가 그 외라면 해당 상태 반환
            return application_status

        # 3. 회원 기록은 있지만 withdrawn이고,
        #    새로운 가입 신청도 없으면 다시 가입 신청 가능
        return None

    # -----------------------------------------------------
    # 동호회 찜 추가
    # -----------------------------------------------------
    def create_club_favorite(
        self,
        club_id: int,
        user_id: str,
    ) -> dict:
        response = (
            self.admin_client
            .table("club_favorites")
            .insert({
                "club_id": club_id,
                "user_id": user_id,
            })
            .execute()
        )

        if not response.data:
            raise ValueError("동호회 찜 추가에 실패했습니다.")

        return response.data[0]

    # -----------------------------------------------------
    # 동호회 찜 취소
    # -----------------------------------------------------
    def delete_club_favorite(
        self,
        club_id: int,
        user_id: str,
    ) -> bool:
        response = (
            self.admin_client
            .table("club_favorites")
            .delete()
            .eq("club_id", club_id)
            .eq("user_id", user_id)
            .execute()
        )

        return bool(response.data)

    # -----------------------------------------------------
    # 동호회 찜 여부 확인
    # -----------------------------------------------------
    def is_club_favorite(
        self,
        club_id: int,
        user_id: str,
    ) -> bool:
        response = (
            self.admin_client
            .table("club_favorites")
            .select("favorite_id")
            .eq("club_id", club_id)
            .eq("user_id", user_id)
            .limit(1)
            .execute()
        )

        return bool(response.data)

    # -----------------------------------------------------
    # 내가 찜한 동호회 목록 조회
    # -----------------------------------------------------
    def get_my_club_favorites(
        self,
        user_id: str,
    ) -> list[dict]:
        response = (
            self.admin_client
            .table("club_favorites")
            .select(
                "favorite_id, club_id, created_at"
            )
            .eq("user_id", user_id)
            .order("created_at", desc=True)
            .execute()
        )

        return response.data or []
    
    # -----------------------------------------------------
    # 종목명으로 sports 조회
    # -----------------------------------------------------
    def find_sport_by_name(
        self,
        sport_name: str,
    ) -> dict | None:

        response = (
            self.admin_client
            .table("sports")
            .select(
                "sport_id, sport_name, status"
            )
            .eq(
                "sport_name",
                sport_name,
            )
            .eq(
                "status",
                True,
            )
            .limit(1)
            .execute()
        )

        if not response.data:
            return None

        return response.data[0]

    # -----------------------------------------------------
    # clubs 기본 정보 저장
    # -----------------------------------------------------
    def create_club(
        self,
        club_data: dict,
    ) -> dict:

        response = (
            self.admin_client
            .table("clubs")
            .insert(club_data)
            .execute()
        )

        if not response.data:
            raise ValueError(
                "동호회 기본 정보 저장에 실패했습니다."
            )

        return response.data[0]

    # -----------------------------------------------------
    # 동호회 종목 연결
    # -----------------------------------------------------
    def create_club_sport(
        self,
        club_id: int,
        sport_id: int,
    ) -> None:

        self.admin_client.table(
            "club_sports"
        ).insert(
            {
                "club_id": club_id,
                "sport_id": sport_id,
            }
        ).execute()

    # -----------------------------------------------------
    # 동호회 활동 지역 저장
    # -----------------------------------------------------
    def create_club_region(
        self,
        club_id: int,
        region: str,
    ) -> None:

        self.admin_client.table(
            "club_regions"
        ).insert(
            {
                "club_id": club_id,
                "region": region,
            }
        ).execute()

    # -----------------------------------------------------
    # 활동 일정 저장
    # -----------------------------------------------------
    def create_club_schedules(
        self,
        schedule_rows: list[dict],
    ) -> None:

        if not schedule_rows:
            return

        self.admin_client.table(
            "club_schedules"
        ).insert(
            schedule_rows
        ).execute()

    # -----------------------------------------------------
    # 동호회 운동 수준 저장
    # -----------------------------------------------------
    def create_club_sport_levels(
        self,
        level_rows: list[dict],
    ) -> None:

        if not level_rows:
            return

        self.admin_client.table(
            "club_sport_levels"
        ).insert(
            level_rows
        ).execute()

    # -----------------------------------------------------
    # 가입 가능 연령대 저장
    # -----------------------------------------------------
    def create_club_age_groups(
        self,
        age_group_rows: list[dict],
    ) -> None:

        if not age_group_rows:
            return

        self.admin_client.table(
            "club_age_groups"
        ).insert(
            age_group_rows
        ).execute()

    # -----------------------------------------------------
    # 동호회 활동 장소 저장
    # -----------------------------------------------------
    def create_club_venue(
        self,
        venue_data: dict,
    ) -> None:

        self.admin_client.table(
            "club_venues"
        ).insert(
            venue_data
        ).execute()

    # -----------------------------------------------------
    # 동호회 소개 키워드 저장
    # -----------------------------------------------------
    def create_club_intro_keywords(
        self,
        keyword_rows: list[dict],
    ) -> None:

        if not keyword_rows:
            return

        self.admin_client.table(
            "club_intro_keywords"
        ).insert(
            keyword_rows
        ).execute()

    # -----------------------------------------------------
    # 동호회 이미지 URL 저장
    # -----------------------------------------------------
    def create_club_images(
        self,
        image_rows: list[dict],
    ) -> None:

        if not image_rows:
            return

        self.admin_client.table(
            "club_images"
        ).insert(
            image_rows
        ).execute()

    # -----------------------------------------------------
    # 가입 질문 저장
    # -----------------------------------------------------
    def create_club_join_questions(
        self,
        question_rows: list[dict],
    ) -> None:

        if not question_rows:
            return

        self.admin_client.table(
            "club_join_questions"
        ).insert(
            question_rows
        ).execute()

    # -----------------------------------------------------
    # 동호회 생성자를 동호회장으로 등록
    # -----------------------------------------------------
    def create_owner_membership(
        self,
        club_id: int,
        user_id: str,
    ) -> None:

        self.admin_client.table(
            "club_members"
        ).insert(
            {
                "club_id": club_id,
                "user_id": user_id,
                "role": "owner",
                "status": "active",
                "join_source": "club_created",
            }
        ).execute()

    # -----------------------------------------------------
    # 동호회 생성 실패 시 생성 데이터 정리
    # -----------------------------------------------------
    def delete_club(
        self,
        club_id: int,
    ) -> None:

        self.admin_client.table(
            "clubs"
        ).delete().eq(
            "club_id",
            club_id,
        ).execute()

    # -----------------------------------------------------
    # 동호회 허브 기본 정보 조회
    # -----------------------------------------------------
    def find_club_by_id(
        self,
        club_id: int,
    ) -> dict | None:

        response = (
            self.admin_client
            .table("clubs")
            .select(
                "club_id, club_name, club_intro, "
                "max_members, monthly_fee, "
                "activity_frequency, gender_rule, "
                "join_method, visibility, status"
            )
            .eq("club_id", club_id)
            .eq("status", True)
            .limit(1)
            .execute()
        )

        if not response.data:
            return None

        return response.data[0]

    # -----------------------------------------------------
    # 동호회 기본 설정 수정
    # -----------------------------------------------------
    def update_club_settings(
        self,
        club_id: int,
        settings_data: dict,
    ) -> dict | None:

        if not settings_data:
            return self.find_club_by_id(
                club_id
            )

        response = (
            self.admin_client
            .table("clubs")
            .update(settings_data)
            .eq("club_id", club_id)
            .eq("status", True)
            .execute()
        )

        if not response.data:
            return None

        return response.data[0]

    # -----------------------------------------------------
    # 동호회 비활성화
    #
    # 실제 데이터를 삭제하지 않고 앱에서 숨긴다.
    # -----------------------------------------------------
    def deactivate_club(
        self,
        club_id: int,
    ) -> dict | None:

        response = (
            self.admin_client
            .table("clubs")
            .update({
                "status": False,
            })
            .eq("club_id", club_id)
            .eq("status", True)
            .execute()
        )

        if not response.data:
            return None

        return response.data[0]

    # -----------------------------------------------------
    # 로그인 사용자의 동호회 권한 조회
    # -----------------------------------------------------
    def find_active_membership(
        self,
        club_id: int,
        user_id: str,
    ) -> dict | None:

        response = (
            self.admin_client
            .table("club_members")
            .select("role, status")
            .eq("club_id", club_id)
            .eq("user_id", user_id)
            .eq("status", "active")
            .limit(1)
            .execute()
        )

        if not response.data:
            return None

        return response.data[0]

    # -----------------------------------------------------
    # 동호회 종목명 조회
    # -----------------------------------------------------
    def find_club_sport_name(
        self,
        club_id: int,
    ) -> str | None:

        club_sport_response = (
            self.admin_client
            .table("club_sports")
            .select("sport_id")
            .eq("club_id", club_id)
            .limit(1)
            .execute()
        )

        if not club_sport_response.data:
            return None

        sport_id = club_sport_response.data[0]["sport_id"]

        sport_response = (
            self.admin_client
            .table("sports")
            .select("sport_name")
            .eq("sport_id", sport_id)
            .limit(1)
            .execute()
        )

        if not sport_response.data:
            return None

        return sport_response.data[0]["sport_name"]

    # -----------------------------------------------------
    # 동호회 대표 지역 조회
    # -----------------------------------------------------
    def find_club_region(
        self,
        club_id: int,
    ) -> str | None:
        response = (
            self.admin_client
            .table("club_regions")
            .select("region")
            .eq("club_id", club_id)
            .limit(1)
            .execute()
        )

        if not response.data:
            return None

        return response.data[0]["region"]


    # -----------------------------------------------------
    # 동호회 활동 장소 조회
    # -----------------------------------------------------
    def find_club_venue(
        self,
        club_id: int,
    ) -> str | None:
        response = (
            self.admin_client
            .table("club_venues")
            .select("venue_name")
            .eq("club_id", club_id)
            .limit(1)
            .execute()
        )

        if not response.data:
            return None

        return response.data[0]["venue_name"]


    # -----------------------------------------------------
    # 동호회 가입 질문 조회
    # -----------------------------------------------------
    def get_join_questions(
        self,
        club_id: int,
    ):
        response = (
            self.supabase
            .table("club_join_questions")
            .select(
                "question_id, club_id, question_text, "
                "question_type, required, display_order"
            )
            .eq("club_id", club_id)
            .order("display_order")
            .execute()
        )

        return response.data or []


    # -----------------------------------------------------
    # 동호회 이미지 조회
    # -----------------------------------------------------
    def find_club_images(
            self,
            club_id: int,
        ) -> list[dict]:

            response = (
                self.admin_client
                .table("club_images")
                .select(
                    "image_url, image_type, display_order"
                )
                .eq("club_id", club_id)
                .order("display_order")
                .execute()
            )

            return response.data

    # -----------------------------------------------------
    # 동호회 가입 신청서 저장
    #
    # 1. club_applications에 가입 신청 생성
    # 2. club_join_answers에 추가 질문 답변 저장
    # -----------------------------------------------------
    def create_application(
        self,
        club_id: int,
        user_id: str,
        application_message: str,
        answers: list,
    ):
        # 1. 가입 신청 생성
        application_data = {
            "club_id": club_id,
            "user_id": user_id,
            "application_message": application_message,
            "status": "pending",
        }

        application_response = (
            self.supabase
            .table("club_applications")
            .insert(application_data)
            .execute()
        )

        if not application_response.data:
            raise ValueError(
                "가입 신청 저장에 실패했습니다."
            )

        application = application_response.data[0]

        application_id = application["application_id"]

        # 2. 추가 질문 답변 저장
        answer_data = []

        for answer in answers:
            answer_data.append(
                {
                    "application_id": application_id,
                    "question_id": answer["question_id"],
                    "answer_text": answer["answer_text"],
                }
            )

        # 답변이 있을 때만 INSERT
        if answer_data:
            (
                self.supabase
                .table("club_join_answers")
                .insert(answer_data)
                .execute()
            )

        # ⭐ 3. 동호회장에게 가입 신청 알림 생성

        # 동호회 이름 조회
        club_response = (
            self.supabase
            .table("clubs")
            .select("club_name")
            .eq("club_id", club_id)
            .limit(1)
            .execute()
        )

        club_name = "동호회"

        if club_response.data:
            club_name = (
                club_response.data[0].get("club_name")
                or "동호회"
            )

                # ⭐ 동호회장에게 가입 신청 알림
        # 알림 저장이 실패해도 가입 신청 자체는 정상 처리
        try:
            owner_response = (
                self.supabase
                .table("club_members")
                .select("user_id")
                .eq("club_id", club_id)
                .eq("role", "owner")
                .eq("status", "active")
                .limit(1)
                .execute()
            )

            if owner_response.data:
                owner_id = owner_response.data[0]["user_id"]

                self.admin_client.table("notifications").insert(
                    {
                        "user_id": owner_id,
                        "notification_type": "club_application",
                        "title": "새로운 가입 신청",
                        "content": (
                            f"{club_name}에 "
                            "새로운 가입 신청이 있습니다."
                        ),
                        "related_type": "club",
                        "related_id": club_id,
                        "is_read": False,
                    }
                ).execute()

        except Exception as e:
            print("가입 신청 알림 생성 실패:", e)

        return application

    # -----------------------------------------------------
    # 동호회 정기 일정 조회
    # -----------------------------------------------------
    def find_club_schedules(
            self,
            club_id: int,
        ) -> list[dict]:

            response = (
                self.admin_client
                .table("club_schedules")
                .select(
                    "club_schedule_id, day_of_week, "
                    "start_time, end_time"
                )
                .eq("club_id", club_id)
                .order("club_schedule_id")
                .execute()
            )

            return response.data or []

    # -----------------------------------------------------
    # 활동 중인 회원 수 조회
    # -----------------------------------------------------
    def count_active_members(
            self,
            club_id: int,
        ) -> int:

            response = (
                self.admin_client
                .table("club_members")
                .select(
                    "club_member_id",
                    count="exact",
                )
                .eq("club_id", club_id)
                .eq("status", "active")
                .execute()
            )

            if response.count is not None:
                return response.count

            return len(response.data or [])

    # =========================================================
    # 모집 중인 동호회 조회
    # =========================================================
    def get_recruiting_clubs(
        self,
        sport_names=None,
        regions=None,
        days=None,
        time_slots=None,
    ):
        params = {
            "p_keyword": None,
            "p_sport_name": sport_names or None,
            "p_region": regions or None,
            "p_day_of_week": days or None,
            "p_time_slot": time_slots or None,
            "p_atmosphere": None,
        }

        response = self.supabase.rpc(
            "search_recruiting_clubs",
            params,
        ).execute()

        return response.data or []

    # =========================================================
    # 게스트 모집 중인 일정 조회
    # =========================================================
    def get_guest_recruiting_events(self):
        current_time = datetime.now(
            ZoneInfo("Asia/Seoul")
        )

        response = (
            self.admin_client
            .table("club_events")
            .select(
                (
                    "event_id, "
                    "club_id, "
                    "title, "
                    "description, "
                    "event_date, "
                    "start_time, "
                    "end_time, "
                    "location, "
                    "location_address, "
                    "latitude, "
                    "longitude, "
                    "max_participants, "
                    "event_image_url, "
                    "guest_allowed, "
                    "max_guests, "
                    "registration_deadline, "
                    "status"
                )
            )
            .eq("guest_allowed", True)
            .eq("status", "open")
            .gte(
                "event_date",
                current_time.date().isoformat(),
            )
            .order(
                "event_date",
                desc=False,
            )
            .order(
                "start_time",
                desc=False,
            )
            .execute()
        )

        recruiting_events = []

        for event in response.data or []:
            deadline_value = event.get(
                "registration_deadline"
            )

            # 신청 마감 시간이 지난 일정 제외
            if deadline_value:
                deadline = datetime.fromisoformat(
                    str(deadline_value).replace(
                        "Z",
                        "+00:00",
                    )
                )

                if deadline.tzinfo is None:
                    deadline = deadline.replace(
                        tzinfo=timezone.utc
                    )

                comparison_time = (
                    current_time.replace(
                        tzinfo=timezone.utc
                    )
                )

                if comparison_time >= deadline:
                    continue

            event_date_value = event.get(
                "event_date"
            )

            start_time_value = event.get(
                "start_time"
            )

            # 오늘 일정 중 이미 시작한 일정 제외
            if (
                event_date_value
                and start_time_value
            ):
                event_start = datetime.combine(
                    date.fromisoformat(
                        str(event_date_value)
                    ),
                    time.fromisoformat(
                        str(start_time_value)
                    ),
                    tzinfo=ZoneInfo("Asia/Seoul"),
                )

                if current_time >= event_start:
                    continue

            recruiting_events.append(event)

        return recruiting_events