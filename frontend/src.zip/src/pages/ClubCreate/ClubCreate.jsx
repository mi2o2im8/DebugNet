import { BackButtonIcon } from "../../components/BackButton/BackButton";
import {
    useEffect,
    useState
} from "react";
import { useNavigate } from "react-router-dom";
import BasicInfoStep from "./BasicInfoStep";
import ScheduleStep from "./ScheduleStep";
import ConditionStep from "./ConditionStep";
import IntroductionStep from "./IntroductionStep";
import OperationStep from "./OperationStep";
import CompletionStep from "./CompletionStep";
import { createClub } from "../../api/clubApi";
import { getMyGender, getMyProfile } from "../../api/userApi";

import "./ClubCreate.css";
import { goBack } from "../../utils/navigation";

const STEP_TITLES = [
    "기본 정보 입력",
    "활동 일정 설정",
    "활동 조건 및 가입 대상",
    "동호회 소개 작성 (AI)",
    "가입 및 운영 방식",
    "개설 완료"
];

function ClubCreate() {
    const navigate = useNavigate();

    // 현재 페이지 단계
    const [currentStep, setCurrentStep] = useState(1);

    // API 요청 중 중복 클릭 방지
    const [isSubmitting, setIsSubmitting] =
        useState(false);

    // 생성된 동호회 API 응답 저장
    const [createResult, setCreateResult] =
        useState(null);

    const [operatorProfile, setOperatorProfile] =
        useState(null);

    const [isOperatorLoading, setIsOperatorLoading] =
        useState(true);

    const [clubForm, setClubForm] = useState({
    // 1단계
    representativeImage: "",
    representativeImageFile: null,
    clubName: "",
    sport: "",
    city: "서울특별시",
    district: "",
    detailLocation: "",

    // 2단계
    schedules: [
            {
                id: 1,
                day: "월요일",
                startTime: "19:00",
                endTime: "21:00",
                enabled: true
            },
            // {
            //     id: 2,
            //     day: "수요일",
            //     startTime: "19:00",
            //     endTime: "21:00",
            //     enabled: true
            // },
            // {
            //     id: 3,
            //     day: "토요일",
            //     startTime: "08:00",
            //     endTime: "10:00",
            //     enabled: true
            // }
        ],

        activityPlace: "여의도 한강공원",
        activityPlaceDetail: "",
        activityFrequency: "주 1회",

        // 3단계
        // activityLevels: [
        //     "수준 무관",
        // ],
        joinTarget: "all",
        // ageGroups: [
        //     "연령 제한 없음",
        //     "30대",
        //     "50대"
        // ],
        noAgeLimit: false,

        // 4단계
        introKeywords: [
            "한강",
            "초보자 환영",
            "즐거운 분위기"
        ],
        clubDescription: "",
        activityImages: [],
        activityImageFiles: [],

        // 5단계
        joinMethod: "approval",
        maxMembers: "50",
        monthlyFee: 30000,
        joinQuestions: [],

    });

    useEffect(() => {
        let isActive = true;

        getMyProfile()
            .then((profile) => {
                if (isActive) {
                    setOperatorProfile(profile);
                }
            })
            .catch((error) => {
                console.error(
                    "운영자 정보 조회 오류:",
                    error
                );

                if (isActive) {
                    setOperatorProfile(null);
                }
            })
            .finally(() => {
                if (isActive) {
                    setIsOperatorLoading(false);
                }
            });

        return () => {
            isActive = false;
        };
    }, []);

    const handleFormChange = (field, value) => {
    setClubForm((previous) => ({
        ...previous,
        [field]: value
    }));
    };

    // 이전 버튼
    const handlePrevious = () => {
        if (currentStep === 1) {
            goBack(navigate);
            return;
        }

        setCurrentStep(currentStep - 1);
        window.scrollTo(0, 0);
    };

    // 로그인 사용자의 성별과 가입 대상 비교
    const confirmGenderTarget = async () => {
        const selectedTarget = clubForm.joinTarget;

        // 남녀 모두라면 별도 확인이 필요하지 않음
        if (selectedTarget === "all") {
            return true;
        }

        try {
            const userData = await getMyGender();
            const userGender = userData.gender;

            // 로그인 사용자 성별과 선택 조건이 같음
            if (userGender === selectedTarget) {
                return true;
            }

            const targetLabel = {
                male: "남성만",
                female: "여성만"
            }[selectedTarget];

            return window.confirm(
                `회원님의 성별과 다른 가입 대상을 선택했습니다.\n` +
                `현재 선택: ${targetLabel}\n\n` +
                `그래도 이 조건으로 계속하시겠습니까?`
            );
        } catch (error) {
            console.error(
                "사용자 성별 확인 오류:",
                error
            );

            alert(
                error.message ||
                "회원 성별 정보를 확인할 수 없습니다."
            );

            return false;
        }
    };

    // 다음 버튼
    const handleNext = async () => {
        if (currentStep >= 6 || isSubmitting) {
            return;
        }

        if (currentStep === 3) {
            const canContinue =
                await confirmGenderTarget();

            if (!canContinue) {
                return;
            }
        }

        if (currentStep < 5) {
            setCurrentStep(currentStep + 1);
            window.scrollTo(0, 0);
            return;
        }

        if (
            clubForm.monthlyFee === ""
            || Number(clubForm.monthlyFee) < 0
        ) {
            alert("월 회비를 0원 이상으로 입력해주세요.");
            return;
        }        

        setIsSubmitting(true);

        try {
            const result = await createClub(clubForm);

            setCreateResult(result);
            setCurrentStep(6);
            window.scrollTo(0, 0);
        } catch (error) {
            console.error(
                "동호회 개설 오류:",
                error
            );

            alert(
                error.message ||
                "동호회 개설 중 오류가 발생했습니다."
            );
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <main className="club-create-page">
            <section className="club-create-container">

                {/* 앱 상단 헤더 */}
                <header className="club-create-header">
                    <button
                        type="button"
                        className="club-create-back-button"
                        onClick={handlePrevious}
                        aria-label="이전 화면으로 이동"
                    >
                        <BackButtonIcon />
                    </button>

                    <h1 className="club-create-header-title">동호회 만들기</h1>

                    <span
                        className="club-create-header-space"
                        aria-hidden="true"
                    />
                </header>

                {/* 진행 단계 */}
                <div className="club-create-progress">

                    <div className="club-create-progress-top">
                        <span className="club-create-step-number">
                            {currentStep}
                        </span>

                        <div className="club-create-progress-track">
                            <div
                                className="club-create-progress-bar"
                                style={{
                                    width: `${(currentStep / 6) * 100}%`
                                }}
                            />
                        </div>
                    </div>

                    <div className="club-create-progress-info">
                        <span>{currentStep}/6</span>

                        <strong>
                            {STEP_TITLES[currentStep - 1]}
                        </strong>
                    </div>

                </div>

                {/* 각 페이지 내용 */}
                <div className="club-create-content">

                    {currentStep === 1 && (
                        <BasicInfoStep
                            formData={clubForm}
                            onChange={handleFormChange}
                            operatorProfile={operatorProfile}
                            isOperatorLoading={isOperatorLoading}
                        />
                    )}

                    {currentStep === 2 && (
                        <ScheduleStep
                            formData={clubForm}
                            onChange={handleFormChange}
                        />
                    )}

                    {currentStep === 3 && (
                        <ConditionStep
                            formData={clubForm}
                            onChange={handleFormChange}
                        />
                    )}

                    {currentStep === 4 && (
                        <IntroductionStep
                            formData={clubForm}
                            onChange={handleFormChange}
                        />
                    )}

                    {currentStep === 5 && (
                        <OperationStep
                            formData={clubForm}
                            onChange={handleFormChange}
                        />
                    )}

                    {currentStep === 6 && (
                        <CompletionStep
                            formData={clubForm}
                            clubId={createResult?.club_id}
                            onRestart={() => setCurrentStep(1)}
                        />
                    )}
                </div>

                {/* 하단 이전/다음 버튼 */}
                <nav className="club-create-navigation">

                    {currentStep > 1 && (
                        <button
                            type="button"
                            className="club-create-button previous"
                            onClick={handlePrevious}
                        >
                            이전
                        </button>
                    )}

                    {currentStep < 6 && (
                        <button
                            type="button"
                            className="club-create-button next"
                            onClick={handleNext}
                            disabled={isSubmitting}
                        >
                            {isSubmitting
                                ? "개설 중..."
                                : currentStep === 5
                                    ? "동호회 개설하기"
                                    : "다음"}
                        </button>
                    )}

                </nav>

            </section>
        </main>
    );
}

export default ClubCreate;