import { supabase } from "../../supabaseClient";
import {
    authenticatedRequest,
    getAuthenticatedSession
} from "./apiClient";

const CLUB_IMAGE_BUCKET = "club-images";

const getFileExtension = (file) => {
    const extension = file.name
        .split(".")
        .pop()
        ?.toLowerCase();

    if (["jpg", "jpeg", "png", "webp"].includes(extension)) {
        return extension;
    }

    return "jpg";
};

const createUploadId = () => {
    if (crypto.randomUUID) {
        return crypto.randomUUID();
    }

    return `${Date.now()}-${Math.random()
        .toString(36)
        .slice(2)}`;
};

const uploadImage = async (
    file,
    filePath,
    uploadedPaths
) => {
    const { error } = await supabase.storage
        .from(CLUB_IMAGE_BUCKET)
        .upload(filePath, file, {
            cacheControl: "3600",
            contentType: file.type,
            upsert: false
        });

    if (error) {
        throw new Error(
            `이미지 업로드에 실패했습니다: ${error.message}`
        );
    }

    uploadedPaths.push(filePath);

    const { data } = supabase.storage
        .from(CLUB_IMAGE_BUCKET)
        .getPublicUrl(filePath);

    return data.publicUrl;
};

const removeUploadedImages = async (filePaths) => {
    if (filePaths.length === 0) {
        return;
    }

    const { error } = await supabase.storage
        .from(CLUB_IMAGE_BUCKET)
        .remove(filePaths);

    if (error) {
        console.error(
            "업로드 이미지 정리 실패:",
            error
        );
    }
};

export const createClub = async (formData) => {
    const session = await getAuthenticatedSession();

    const userId = session.user.id;
    const uploadId = createUploadId();
    const uploadRoot =
        `${userId}/clubs/${uploadId}`;

    const uploadedPaths = [];

    try {
        let representativeImageUrl = null;

        if (formData.representativeImageFile) {
            const file =
                formData.representativeImageFile;

            const extension =
                getFileExtension(file);

            representativeImageUrl =
                await uploadImage(
                    file,
                    `${uploadRoot}/representative.${extension}`,
                    uploadedPaths
                );
        }

        const activityImageUrls = [];

        for (
            let index = 0;
            index < formData.activityImageFiles.length;
            index += 1
        ) {
            const file =
                formData.activityImageFiles[index];

            const extension =
                getFileExtension(file);

            const imageUrl = await uploadImage(
                file,
                `${uploadRoot}/activity-${index + 1}.${extension}`,
                uploadedPaths
            );

            activityImageUrls.push(imageUrl);
        }

        const requestData = {
            representativeImageUrl,
            clubName: formData.clubName,
            sport: formData.sport,
            city: formData.city,
            district: formData.district,
            detailLocation:
                formData.detailLocation || null,

            schedules: formData.schedules.map(
                (schedule) => ({
                    day: schedule.day,
                    startTime: schedule.startTime,
                    endTime: schedule.endTime,
                    enabled: schedule.enabled
                })
            ),

            activityPlace: formData.activityPlace,
            activityPlaceDetail:
                formData.activityPlaceDetail || null,
            activityFrequency:
                formData.activityFrequency,

            activityLevels:
                formData.activityLevels,
            joinTarget: formData.joinTarget,
            ageGroups: formData.ageGroups,
            noAgeLimit: formData.noAgeLimit,

            introKeywords:
                formData.introKeywords,
            clubDescription:
                formData.clubDescription,
            activityImageUrls,

            joinMethod: formData.joinMethod,
            isRecruiting: formData.isRecruiting,
            maxMembers: formData.maxMembers,
            monthlyFee: Number(formData.monthlyFee),

            joinQuestions:
                formData.joinQuestions.map(
                    (question) => ({
                        question: question.question
                    })
                ),

            visibility: "public"
        };

        return await authenticatedRequest(
            "/api/clubs",
            {
                method: "POST",
                body: requestData
            }
        );
    } catch (error) {
        await removeUploadedImages(uploadedPaths);
        throw error;
    }
};

export async function getClubDashboard(clubId) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/dashboard`,
        {
            method: "GET"
        }
    );
}

// ---------------------------------------------------------
// 동호회 설정 조회
// ---------------------------------------------------------
export async function getClubSettings(clubId) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/settings`,
        {
            method: "GET"
        }
    );
}


// ---------------------------------------------------------
// 동호회 기본 설정 수정
// ---------------------------------------------------------
export async function updateClubSettings(
    clubId,
    requestData
) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/settings`,
        {
            method: "PATCH",
            body: requestData
        }
    );
}

// ---------------------------------------------------------
// 운영자용 가입 질문 목록 조회
// ---------------------------------------------------------
export async function getClubJoinQuestionSettings(
    clubId
) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/settings/join-questions`,
        {
            method: "GET"
        }
    );
}


// ---------------------------------------------------------
// 가입 질문 전체 교체
// ---------------------------------------------------------
export async function replaceClubJoinQuestions(
    clubId,
    questions
) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/settings/join-questions`,
        {
            method: "PUT",
            body: {
                questions
            }
        }
    );
}

// ---------------------------------------------------------
// 동호회 활동 정보 설정 조회
// ---------------------------------------------------------
export async function getClubActivitySettings(clubId) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/settings/activity`,
        {
            method: "GET"
        }
    );
}


// ---------------------------------------------------------
// 동호회 활동 정보 설정 수정
// ---------------------------------------------------------
export async function updateClubActivitySettings(
    clubId,
    requestData
) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/settings/activity`,
        {
            method: "PUT",
            body: requestData
        }
    );
}

// ---------------------------------------------------------
// 동호회 삭제
//
// 실제 DB 행은 삭제하지 않고 비활성화한다.
// ---------------------------------------------------------
export async function deleteClub(
    clubId,
    confirmationText
) {
    return authenticatedRequest(
        `/api/clubs/${clubId}`,
        {
            method: "DELETE",
            body: {
                confirmationText
            }
        }
    );
}

// 이용자용 동호회 대시보드 조회
export async function getClubUserDashboard(clubId) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/user-dashboard`,
        { method: "GET" }
    );
}

export async function getClubEvents(clubId) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/events`,
        {
            method: "GET"
        }
    );
}

// ---------------------------------------------------------
// 게스트 모집 중인 일정 조회
// ---------------------------------------------------------
export async function getGuestRecruitingEvents() {
    return authenticatedRequest(
        "/api/clubs/guest-recruiting",
        {
            method: "GET"
        }
    );
}

export async function createClubEvent(
    clubId,
    requestData
) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/events`,
        {
            method: "POST",
            body: requestData
        }
    );
}

export async function getClubEventRecommendations(
    clubId,
    requestData
) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/events/recommendations`,
        {
            method: "POST",
            body: requestData
        }
    );
}

export async function getClubEvent(
    clubId,
    eventId
) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/events/${eventId}`,
        {
            method: "GET"
        }
    );
}

export async function updateClubEvent(
    clubId,
    eventId,
    requestData
) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/events/${eventId}`,
        {
            method: "PUT",
            body: requestData
        }
    );
}

export async function copyClubEvent(
    clubId,
    eventId
) {
    return authenticatedRequest(
        (
            `/api/clubs/${clubId}/events/` +
            `${eventId}/copy`
        ),
        {
            method: "POST"
        }
    );
}

export async function deleteClubEvent(
    clubId,
    eventId
) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/events/${eventId}`,
        {
            method: "DELETE"
        }
    );
}

export async function getClubEventParticipants(
    clubId,
    eventId
) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/events/${eventId}/participants`,
        {
            method: "GET"
        }
    );
}

export async function decideClubEventParticipant(
    clubId,
    eventId,
    eventParticipantId,
    decision
) {
    return authenticatedRequest(
        (
            `/api/clubs/${clubId}/events/${eventId}` +
            `/participants/${eventParticipantId}/decision`
        ),
        {
            method: "PATCH",
            body: {
                decision
            }
        }
    );
}

// ---------------------------------------------------------
// 운영자: 승인된 게스트 일정 참여 취소
// ---------------------------------------------------------
export async function cancelClubEventGuestParticipant(
    clubId,
    eventId,
    eventParticipantId
) {
    return authenticatedRequest(
        (
            `/api/clubs/${clubId}/events/${eventId}`
            + `/participants/${eventParticipantId}`
        ),
        {
            method: "DELETE"
        }
    );
}


// ---------------------------------------------------------
// 게스트 일정 참가 신청
// ---------------------------------------------------------
export async function applyClubEventAsGuest(
    clubId,
    eventId
) {
    return authenticatedRequest(
        (
            `/api/clubs/${clubId}/events/${eventId}`
            + "/guest-application"
        ),
        {
            method: "POST"
        }
    );
}


// ---------------------------------------------------------
// 내 게스트 신청 상태 조회
// ---------------------------------------------------------
export async function getMyClubEventGuestApplication(
    clubId,
    eventId
) {
    return authenticatedRequest(
        (
            `/api/clubs/${clubId}/events/${eventId}`
            + "/guest-application"
        ),
        {
            method: "GET"
        }
    );
}


// ---------------------------------------------------------
// 내 게스트 신청 취소
// ---------------------------------------------------------
export async function cancelMyClubEventGuestApplication(
    clubId,
    eventId
) {
    return authenticatedRequest(
        (
            `/api/clubs/${clubId}/events/${eventId}`
            + "/guest-application"
        ),
        {
            method: "DELETE"
        }
    );
}

export async function updateClubEventParticipantAttendance(
    clubId,
    eventId,
    eventParticipantId,
    attendanceStatus
) {
    return authenticatedRequest(
        (
            `/api/clubs/${clubId}/events/${eventId}`
            + `/participants/${eventParticipantId}`
            + "/attendance"
        ),
        {
            method: "PATCH",
            body: {
                attendanceStatus
            }
        }
    );
}

export async function getClubEventAttendance(
    clubId,
    eventId
) {
    return authenticatedRequest(
        (
            `/api/clubs/${clubId}/events/`
            + `${eventId}/attendance`
        ),
        {
            method: "GET"
        }
    );
}

export async function updateClubEventAttendance(
    clubId,
    eventId,
    attendanceStatus
) {
    return authenticatedRequest(
        (
            `/api/clubs/${clubId}/events/`
            + `${eventId}/attendance`
        ),
        {
            method: "PUT",
            body: {
                attendanceStatus
            }
        }
    );
}
// =========================================================
// 동호회 일정 출석 조회 및 출석 상태 변경
// =========================================================    
export async function getClubScheduleAttendance(
    clubId,
    scheduleId,
    date
) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/events/schedules/${scheduleId}/attendance?date=${date}`,
        {
            method: "GET",
        }
    );
}

export async function updateClubScheduleAttendance(
    clubId,
    scheduleId,
    date,
    attendanceStatus
) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/events/schedules/${scheduleId}/attendance?date=${date}`,
        {
            method: "PUT",
            body: {
                attendanceStatus,
            },
        }
    );
}

// =========================================================
// 동호회 활동 후기
// =========================================================

// ---------------------------------------------------------
// 활동 후기 작성
// ---------------------------------------------------------
export async function createEventReview(
    clubId,
    eventId,
    rating,
    reviewText
) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/events/${eventId}/reviews`,
        {
            method: "POST",
            body: {
                rating,
                review_text: reviewText,
            },
        }
    );
}

// ---------------------------------------------------------
// 내가 작성한 활동 후기 조회
// ---------------------------------------------------------
export async function getMyEventReview(
    clubId,
    eventId
) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/events/${eventId}/reviews/me`,
        {
            method: "GET",
        }
    );
}

// ---------------------------------------------------------
// 동호회의 전체 활동 후기 조회
// ---------------------------------------------------------
export async function getClubReviews(
    clubId
) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/events/reviews`,
        {
            method: "GET",
        }
    );
}

// -----------------------------------------------------
// 동호회 전체 탈퇴 후기 조회
// -----------------------------------------------------
export async function getClubLeaveReviews(
    clubId
) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/events/leave-reviews`,
        {
            method: "GET",
        }
    );
}

// ---------------------------------------------------------
// 특정 활동의 후기 목록 조회
// ---------------------------------------------------------
export async function getEventReviews(
    clubId,
    eventId
) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/events/${eventId}/reviews`,
        {
            method: "GET",
        }
    );
}
// ---------------------------------------------------------
// 현재 동호회 회원 목록 조회
// ---------------------------------------------------------
export async function getClubMembers(
    clubId
) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/members`,
        {
            method: "GET"
        }
    );
}

// ---------------------------------------------------------
// 동호회 회원 상세 조회
// ---------------------------------------------------------
export async function getClubMemberDetail(
    clubId,
    clubMemberId
) {
    return authenticatedRequest(
        (
            `/api/clubs/${clubId}/members/`
            + clubMemberId
        ),
        {
            method: "GET"
        }
    );
}

// ---------------------------------------------------------
// 동호회 가입 신청 목록 조회
// ---------------------------------------------------------
export async function getClubApplications(
    clubId,
    applicationStatus = "pending"
) {
    const query = new URLSearchParams({
        application_status: applicationStatus
    });

    return authenticatedRequest(
        (
            `/api/clubs/${clubId}/applications`
            + `?${query.toString()}`
        ),
        {
            method: "GET"
        }
    );
}


// ---------------------------------------------------------
// H1 운영자용 모집 대상 추천
// ---------------------------------------------------------
export async function getClubRecruitmentRecommendations(
    clubId,
    limit = 10
) {
    const query = new URLSearchParams({
        limit: String(limit)
    });

    return authenticatedRequest(
        (
            `/api/clubs/${clubId}/recruitment-recommendations`
            + `?${query.toString()}`
        ),
        {
            method: "GET"
        }
    );
}


// ---------------------------------------------------------
// H4 실제 활동 결과 입력 화면 데이터
// ---------------------------------------------------------
export async function getClubActivityResults(
    clubId,
    limit = 8
) {
    const query = new URLSearchParams({
        limit: String(limit)
    });

    return authenticatedRequest(
        (
            `/api/clubs/${clubId}/activity-results`
            + `?${query.toString()}`
        ),
        {
            method: "GET"
        }
    );
}


// ---------------------------------------------------------
// H4 일정별 실제 활동 결과 저장
// ---------------------------------------------------------
export async function saveClubActivityResults(
    clubId,
    eventId,
    results
) {
    return authenticatedRequest(
        (
            `/api/clubs/${clubId}/events/${eventId}`
            + "/activity-results"
        ),
        {
            method: "PUT",
            body: {
                results
            }
        }
    );
}


// ---------------------------------------------------------
// H4 회원 참여 저하 위험 조회
// ---------------------------------------------------------
export async function getClubParticipationRisks(
    clubId
) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/participation-risks`,
        {
            method: "GET"
        }
    );
}


// ---------------------------------------------------------
// 동호회 가입 신청 승인·거절
// ---------------------------------------------------------
export async function decideClubApplication(
    clubId,
    applicationId,
    decision
) {
    return authenticatedRequest(
        (
            `/api/clubs/${clubId}/applications/`
            + `${applicationId}/decision`
        ),
        {
            method: "PATCH",
            body: {
                decision
            }
        }
    );
}

// =========================================================
// ⭐ 내 동호회 조회
//
// 운영 중인 동호회 또는
// 운영자 승인을 받아 가입한 동호회 확인
// =========================================================

export async function getMyClub() {
    return authenticatedRequest(
        "/api/clubs/my",
        {
            method: "GET"
        }
    );
}


// =========================================================
// ⭐ 특정 동호회 가입 상태 조회
//
// pending
//   → 승인 대기
//
// active
//   → 운영자 승인 완료 + 정식 회원
//
// rejected
//   → 가입 거절
// =========================================================

export async function getClubMemberStatus(
    clubId,
    userId
) {
    const query = new URLSearchParams({
        user_id: userId
    });

    return authenticatedRequest(
        (
            `/api/clubs/${clubId}/member-status`
            + `?${query.toString()}`
        ),
        {
            method: "GET"
        }
    );
}


// ---------------------------------------------------------
// 회원 역할 변경
// ---------------------------------------------------------
export async function updateClubMemberRole(
    clubId,
    clubMemberId,
    role
) {
    return authenticatedRequest(
        (
            `/api/clubs/${clubId}/members/`
            + `${clubMemberId}/role`
        ),
        {
            method: "PATCH",
            body: {
                role
            }
        }
    );
}


// ---------------------------------------------------------
// 회원 활동 상태 변경
// ---------------------------------------------------------
export async function updateClubMemberStatus(
    clubId,
    clubMemberId,
    memberStatus
) {
    return authenticatedRequest(
        (
            `/api/clubs/${clubId}/members/`
            + `${clubMemberId}/status`
        ),
        {
            method: "PATCH",
            body: {
                status: memberStatus
            }
        }
    );
}


// ---------------------------------------------------------
// 동호회 회원 내보내기
// ---------------------------------------------------------
export async function removeClubMember(
    clubId,
    clubMemberId
) {
    return authenticatedRequest(
        (
            `/api/clubs/${clubId}/members/`
            + clubMemberId
        ),
        {
            method: "DELETE"
        }
    );
}

// ---------------------------------------------------------
// 내가 가입한 동호회 탈퇴
// ---------------------------------------------------------
export async function withdrawMyClub(
    clubId,
    {
        rating = null,
        leave_reason = null,
        review_text = null,
    } = {}
) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/members/me`,
        {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                rating,
                leave_reason,
                review_text,
            }),
        }
    );
}

// ---------------------------------------------------------
// 회원 경고 부여
// ---------------------------------------------------------
export async function createClubMemberWarning(
    clubId,
    clubMemberId,
    warningType,
    reason
) {
    return authenticatedRequest(
        (
            `/api/clubs/${clubId}/members/`
            + `${clubMemberId}/warnings`
        ),
        {
            method: "POST",
            body: {
                warning_type: warningType,
                reason
            }
        }
    );
}


// ---------------------------------------------------------
// 회원 경고 취소
// ---------------------------------------------------------
export async function deleteClubMemberWarning(
    clubId,
    clubMemberId,
    warningId
) {
    return authenticatedRequest(
        (
            `/api/clubs/${clubId}/members/`
            + `${clubMemberId}/warnings/`
            + warningId
        ),
        {
            method: "DELETE"
        }
    );
}

// ---------------------------------------------------------
// 맞춤 동호회 추천 기본값
// 로그인 사용자가 회원가입/내 정보에 저장한 값을 그대로 사용한다.
// ---------------------------------------------------------
export async function getClubRecommendationDefaults() {
    return authenticatedRequest(
        "/api/clubs/recommend/defaults",
        { method: "GET" }
    );
}

// ---------------------------------------------------------
// 맞춤 동호회 추천 실행
// 화면에서 바꾼 조건은 이번 추천에만 사용하며 내 정보는 수정하지 않는다.
// ---------------------------------------------------------
export async function recommendClubs(requestData) {
    return authenticatedRequest(
        "/api/clubs/recommend",
        {
            method: "POST",
            body: requestData,
        }
    );
}

// -----------------------------------------------------
// 동호회 찜 추가
// -----------------------------------------------------
export async function createClubFavorite(clubId) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/favorite`,
        {
            method: "POST",
        }
    );
}

// -----------------------------------------------------
// 동호회 찜 취소
// -----------------------------------------------------
export async function deleteClubFavorite(clubId) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/favorite`,
        {
            method: "DELETE",
        }
    );
}

// -----------------------------------------------------
// 동호회 찜 여부 확인
// -----------------------------------------------------
export async function getClubFavorite(clubId) {
    return authenticatedRequest(
        `/api/clubs/${clubId}/favorite`,
        {
            method: "GET",
        }
    );
}

// -----------------------------------------------------
// 내가 찜한 동호회 목록 조회
// -----------------------------------------------------
export async function getMyClubFavorites() {
    return authenticatedRequest(
        `/api/clubs/favorites`,
        {
            method: "GET",
        }
    );
}