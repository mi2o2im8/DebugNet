// 신청 현황 페이지 (마이페이지 → 신청 현황)
//
// 동호회 가입 신청: 승인 대기 / 가입 완료 / 탈퇴함 / 거절됨
// 게스트 신청:      승인 대기 / 참여 확정 / 참여 완료 / 거절됨 / 신청 취소 / 일정 취소
//
// GET /api/users/me/applications 한 번으로 두 목록을 같이 받는다.

import { useEffect, useMemo, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";

import BackButton from "../../components/BackButton/BackButton";
import BottomNav from "../../components/BottomNav";

import { getMyApplications } from "../../api/userApi";
import { cancelMyClubEventGuestApplication } from "../../api/clubApi";

import "./MyApplications.css";


/* ========================================
   ⭐ 탭
   ======================================== */

const TABS = [
    { key: "club", label: "동호회 가입" },
    { key: "guest", label: "게스트 신청" },
];


/* ========================================
   ⭐ 날짜 / 시간 표시
   ======================================== */

const WEEKDAYS = ["일", "월", "화", "수", "목", "금", "토"];

// "2026-09-27" → "9월 27일 (일)"
const formatEventDate = (dateString) => {

    if (!dateString) return "";

    const [year, month, day] = String(dateString)
        .slice(0, 10)
        .split("-")
        .map(Number);

    const weekday = WEEKDAYS[new Date(year, month - 1, day).getDay()];

    return `${month}월 ${day}일 (${weekday})`;
};

// "2026-09-20T10:00:00+00:00" → "9월 20일"
const formatAppliedDate = (dateTimeString) => {

    if (!dateTimeString) return "";

    const date = new Date(dateTimeString);

    if (Number.isNaN(date.getTime())) return "";

    return `${date.getMonth() + 1}월 ${date.getDate()}일`;
};

// "18:00:00" → "18:00"
const formatTime = (timeString) =>
    timeString ? String(timeString).slice(0, 5) : "";


/* ========================================
   ⭐ 일정 시작 / 종료 여부 (한국 시간 기준, 기기 시간 사용)
   ======================================== */

const toDateTime = (dateString, timeString) => {

    if (!dateString || !timeString) return null;

    const [year, month, day] = String(dateString)
        .slice(0, 10)
        .split("-")
        .map(Number);

    const [hour, minute] = String(timeString)
        .split(":")
        .map(Number);

    return new Date(year, month - 1, day, hour || 0, minute || 0);
};

const hasStarted = (item) => {
    const startAt = toDateTime(item.event_date, item.start_time);
    return startAt ? Date.now() >= startAt.getTime() : false;
};

const hasEnded = (item) => {
    // 종료 시간이 없으면 시작 시간 기준
    const endAt = toDateTime(
        item.event_date,
        item.end_time || item.start_time
    );
    return endAt ? Date.now() >= endAt.getTime() : false;
};


/* ========================================
   ⭐ 동호회 가입 신청 상태
   ======================================== */

const getClubStatus = (item) => {

    if (item.status === "pending") {
        return { label: "승인 대기", tone: "waiting" };
    }

    if (item.status === "approved") {
        return item.is_active_member
            ? { label: "가입 완료", tone: "done" }
            : { label: "탈퇴함", tone: "muted" };
    }

    if (item.status === "rejected") {
        return { label: "거절됨", tone: "rejected" };
    }

    return { label: item.status, tone: "muted" };
};


/* ========================================
   ⭐ 게스트 신청 상태
   ======================================== */

const getGuestStatus = (item) => {

    if (item.event_status === "cancelled") {
        return { label: "일정 취소", tone: "muted" };
    }

    if (item.guest_status === "pending") {
        return hasStarted(item)
            ? { label: "미승인 마감", tone: "muted" }
            : { label: "승인 대기", tone: "waiting" };
    }

    if (item.guest_status === "joined") {
        if (hasEnded(item)) return { label: "참여 완료", tone: "finished" };
        if (hasStarted(item)) return { label: "진행 중", tone: "done" };
        return { label: "참여 확정", tone: "done" };
    }

    if (item.guest_status === "rejected") {
        return { label: "거절됨", tone: "rejected" };
    }

    if (item.guest_status === "cancelled") {
        return { label: "신청 취소", tone: "muted" };
    }

    return { label: item.guest_status, tone: "muted" };
};

// 시작 전이고 아직 살아있는 신청만 취소 가능
const canCancelGuest = (item) =>
    item.event_status !== "cancelled" &&
    (item.guest_status === "pending" || item.guest_status === "joined") &&
    !hasStarted(item);


function MyApplications() {

    const navigate = useNavigate();
    const [searchParams, setSearchParams] = useSearchParams();


    // =========================================================
    // ⭐ 상태
    // =========================================================
    const activeTab =
        searchParams.get("tab") === "guest" ? "guest" : "club";

    const [clubApplications, setClubApplications] = useState([]);
    const [guestApplications, setGuestApplications] = useState([]);

    const [loading, setLoading] = useState(true);
    const [errorMessage, setErrorMessage] = useState("");

    // 취소 요청 중인 게스트 신청 (중복 클릭 방지)
    const [cancellingEventId, setCancellingEventId] = useState(null);


    // =========================================================
    // ⭐ 데이터 불러오기
    // =========================================================
    useEffect(() => {

        let ignore = false;

        const fetchApplications = async () => {

            try {

                setLoading(true);
                setErrorMessage("");

                const data = await getMyApplications();

                if (ignore) return;

                setClubApplications(data?.club_applications ?? []);
                setGuestApplications(data?.guest_applications ?? []);

            } catch (error) {

                if (ignore) return;

                console.error("신청 현황 조회 오류:", error);
                setErrorMessage(error.message);

            } finally {

                if (!ignore) setLoading(false);

            }
        };

        fetchApplications();

        return () => {
            ignore = true;
        };

    }, []);


    // =========================================================
    // ⭐ 탭별 "진행 중" 개수 (승인 대기 등 아직 결과가 안 난 것)
    // =========================================================
    const waitingCount = useMemo(() => ({
        club: clubApplications.filter(
            (item) => item.status === "pending"
        ).length,
        guest: guestApplications.filter(
            (item) => getGuestStatus(item).tone === "waiting"
        ).length,
    }), [clubApplications, guestApplications]);


    const changeTab = (tabKey) => {
        setSearchParams(
            tabKey === "guest" ? { tab: "guest" } : {},
            { replace: true }
        );
    };


    // =========================================================
    // ⭐ 카드 누르면 이동할 곳
    // =========================================================
    const handleClubClick = (item) => {

        // 활동 중인 동호회 → 동호회 홈, 그 외 → 동호회 소개
        if (item.status === "approved" && item.is_active_member) {
            navigate(`/clubs/${item.club_id}/home`);
            return;
        }

        navigate(`/clubs/${item.club_id}`);
    };

    const getGuestClickAction = (item) => {

        if (item.event_status === "cancelled") return null;

        // 참여 완료 → 경기 후기 페이지
        if (item.guest_status === "joined" && hasEnded(item)) {
            return () => navigate("/my-reviews");
        }

        // 시작 전 신청 → 게스트 모집 상세 (일정 정보 그대로 전달)
        if (
            (item.guest_status === "pending" ||
                item.guest_status === "joined") &&
            !hasStarted(item)
        ) {
            return () =>
                navigate(`/guest-recruit/${item.event_id}`, {
                    state: { event: item },
                });
        }

        return null;
    };


    // =========================================================
    // ⭐ 게스트 신청 취소
    // =========================================================
    const handleCancelGuest = async (item) => {

        if (cancellingEventId) return;

        const message =
            item.guest_status === "joined"
                ? "참여 확정된 게스트 신청을 취소할까요?\n취소하면 다시 승인을 받아야 해요."
                : "게스트 신청을 취소할까요?";

        if (!window.confirm(message)) return;

        setCancellingEventId(item.event_id);

        try {

            await cancelMyClubEventGuestApplication(
                item.club_id,
                item.event_id
            );

            setGuestApplications((current) =>
                current.map((guestItem) =>
                    guestItem.event_id === item.event_id
                        ? { ...guestItem, guest_status: "cancelled" }
                        : guestItem
                )
            );

        } catch (error) {

            console.error("게스트 신청 취소 실패:", error);
            alert(error?.message || "게스트 신청 취소에 실패했습니다.");

        } finally {

            setCancellingEventId(null);

        }
    };


    // =========================================================
    // ⭐ 목록 화면
    // =========================================================
    const renderClubList = () => {

        if (clubApplications.length === 0) {
            return (
                <div className="my-apps-empty">
                    <p>아직 가입 신청한 동호회가 없어요.</p>
                    <button
                        type="button"
                        onClick={() => navigate("/clubs/recruit")}
                    >
                        모집 중인 동호회 보기
                    </button>
                </div>
            );
        }

        return (
            <ul className="my-apps-list">
                {clubApplications.map((item) => {

                    const statusInfo = getClubStatus(item);

                    return (
                        <li
                            key={`club-${item.application_id}`}
                            className="my-apps-card"
                        >
                            <button
                                type="button"
                                className="my-apps-card-main"
                                onClick={() => handleClubClick(item)}
                            >
                                {item.club_image_url ? (
                                    <img
                                        className="my-apps-thumb"
                                        src={item.club_image_url}
                                        alt=""
                                    />
                                ) : (
                                    <span
                                        className="my-apps-thumb placeholder"
                                        aria-hidden="true"
                                    >
                                        {item.club_name?.slice(0, 1)}
                                    </span>
                                )}

                                <span className="my-apps-info">
                                    <span className="my-apps-name">
                                        {item.club_name}
                                    </span>

                                    <span className="my-apps-meta">
                                        {formatAppliedDate(item.created_at)} 신청
                                        {item.decided_at &&
                                            item.status !== "pending" &&
                                            ` · ${formatAppliedDate(item.decided_at)} 처리`}
                                    </span>
                                </span>

                                <span className={`my-apps-status ${statusInfo.tone}`}>
                                    {statusInfo.label}
                                </span>
                            </button>
                        </li>
                    );
                })}
            </ul>
        );
    };

    const renderGuestList = () => {

        if (guestApplications.length === 0) {
            return (
                <div className="my-apps-empty">
                    <p>아직 게스트로 신청한 경기가 없어요.</p>
                    <button
                        type="button"
                        onClick={() => navigate("/guest-recruit")}
                    >
                        게스트 모집 보기
                    </button>
                </div>
            );
        }

        return (
            <ul className="my-apps-list">
                {guestApplications.map((item) => {

                    const statusInfo = getGuestStatus(item);
                    const clickAction = getGuestClickAction(item);
                    const showCancel = canCancelGuest(item);
                    const isCancelling = cancellingEventId === item.event_id;

                    const content = (
                        <>
                            {item.event_image_url ? (
                                <img
                                    className="my-apps-thumb"
                                    src={item.event_image_url}
                                    alt=""
                                />
                            ) : (
                                <span
                                    className="my-apps-thumb placeholder guest"
                                    aria-hidden="true"
                                >
                                    {item.club_name?.slice(0, 1)}
                                </span>
                            )}

                            <span className="my-apps-info">
                                <span className="my-apps-name">
                                    {item.title}
                                </span>

                                <span className="my-apps-meta">
                                    {formatEventDate(item.event_date)}{" "}
                                    {formatTime(item.start_time)}
                                    {item.location && ` · ${item.location}`}
                                </span>

                                <span className="my-apps-club">
                                    {item.club_name}
                                </span>
                            </span>

                            <span className={`my-apps-status ${statusInfo.tone}`}>
                                {statusInfo.label}
                            </span>
                        </>
                    );

                    return (
                        <li
                            key={`guest-${item.event_participant_id}`}
                            className="my-apps-card"
                        >
                            {clickAction ? (
                                <button
                                    type="button"
                                    className="my-apps-card-main"
                                    onClick={clickAction}
                                >
                                    {content}
                                </button>
                            ) : (
                                <div className="my-apps-card-main static">
                                    {content}
                                </div>
                            )}

                            {showCancel && (
                                <button
                                    type="button"
                                    className="my-apps-cancel"
                                    onClick={() => handleCancelGuest(item)}
                                    disabled={isCancelling}
                                >
                                    {isCancelling ? "취소 중..." : "신청 취소"}
                                </button>
                            )}
                        </li>
                    );
                })}
            </ul>
        );
    };


    // =========================================================
    // ⭐ 화면
    // =========================================================
    return (
        <div className="my-apps-page">

            {/* ⭐ 헤더 */}
            <div className="my-apps-header">
                <BackButton
                    className="my-apps-back-btn"
                    aria-label="뒤로가기"
                />

                <h2 className="my-apps-title">
                    신청 현황
                </h2>
            </div>


            {/* ⭐ 탭 */}
            <div className="my-apps-tabs" role="tablist">
                {TABS.map((tab) => (
                    <button
                        key={tab.key}
                        type="button"
                        role="tab"
                        aria-selected={activeTab === tab.key}
                        className={
                            activeTab === tab.key
                                ? "my-apps-tab active"
                                : "my-apps-tab"
                        }
                        onClick={() => changeTab(tab.key)}
                    >
                        {tab.label}
                        {!loading && waitingCount[tab.key] > 0 && (
                            <span className="my-apps-tab-count">
                                대기 {waitingCount[tab.key]}
                            </span>
                        )}
                    </button>
                ))}
            </div>


            {loading ? (

                <p className="my-apps-message">
                    신청 현황을 불러오는 중...
                </p>

            ) : errorMessage ? (

                <p className="my-apps-message">
                    신청 현황을 불러오지 못했습니다.
                    <br />
                    {errorMessage}
                </p>

            ) : activeTab === "club" ? (

                renderClubList()

            ) : (

                renderGuestList()

            )}


            {/* ⭐ 공통 하단 네비게이션 */}
            <BottomNav />

        </div>
    );
}


export default MyApplications;
