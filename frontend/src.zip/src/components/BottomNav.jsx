import "./css/BottomNav.css";
import { NavLink, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";

import {
  FiHome,
  FiUsers,
  FiRepeat,
  FiMessageCircle,
  FiUser
} from "react-icons/fi";

import { supabase } from "../../supabaseClient";


function BottomNav() {
  const navigate = useNavigate();

  // ⭐ 동호회 가입/운영 여부
  const [hasClub, setHasClub] = useState(false);


  // ⭐ 현재 사용자의 동호회 확인
  useEffect(() => {
    const checkMyClub = async () => {
      try {
        const {
          data: { user }
        } = await supabase.auth.getUser();

        if (!user) {
          setHasClub(false);
          return;
        }

        console.log("⭐ BottomNav 현재 user:", user.id);


        // =====================================================
        // ⭐ 1. 운영 중인 동호회 확인
        // clubs.owner_id = 현재 사용자
        // =====================================================

        const {
          data: operatingClub,
          error: operatingError
        } = await supabase
          .from("clubs")
          .select("club_id, club_name, owner_id")
          .eq("owner_id", user.id)
          .limit(1);

        console.log(
          "⭐ BottomNav 운영 동호회:",
          operatingClub
        );

        console.log(
          "⭐ BottomNav 운영 동호회 오류:",
          operatingError
        );


        // ⭐ 운영자라면 MainHome
        if (
          !operatingError &&
          operatingClub &&
          operatingClub.length > 0
        ) {
          console.log(
            "⭐ 운영자 확인 → MainHome"
          );

          setHasClub(true);
          return;
        }


        // =====================================================
        // ⭐ 2. 가입한 동호회 확인
        // =====================================================

        const {
          data: joinedClub,
          error: joinedError
        } = await supabase
          .from("club_members")
          .select("club_id, role, status")
          .eq("user_id", user.id)
          .limit(1);

        console.log(
          "⭐ BottomNav 가입 동호회:",
          joinedClub
        );

        console.log(
          "⭐ BottomNav 가입 동호회 오류:",
          joinedError
        );


        // ⭐ 가입자라면 MainHome
        if (
          !joinedError &&
          joinedClub &&
          joinedClub.length > 0
        ) {
          console.log(
            "⭐ 가입자 확인 → MainHome"
          );

          setHasClub(true);
          return;
        }


        // =====================================================
        // ⭐ 3. 동호회 없음
        // =====================================================

        console.log(
          "⭐ 동호회 없음 → Main"
        );

        setHasClub(false);

      } catch (error) {
        console.error(
          "⭐ BottomNav 동호회 확인 오류:",
          error
        );

        setHasClub(false);
      }
    };

    checkMyClub();
  }, []);


  // =====================================================
  // ⭐ 활동 버튼
  // =====================================================

  const handleActivityClick = (e) => {
    e.preventDefault();

    console.log(
      "⭐ 활동 클릭 - hasClub:",
      hasClub
    );

    if (hasClub) {
      console.log(
        "⭐ 가입자/운영자 → MainHome 이동"
      );

      navigate("/mainhome");
    } else {
      console.log(
        "⭐ 미가입자 → Main 이동"
      );

      navigate("/main");
    }
  };


  return (
    <nav className="bottom-nav">

      {/* 활동 */}
      <NavLink
        to={hasClub ? "/mainhome" : "/main"}
        onClick={handleActivityClick}
        className={({ isActive }) =>
          isActive
            ? "bottom-nav-item active"
            : "bottom-nav-item"
        }
      >
        <FiHome className="bottom-nav-icon" />
        <span>활동</span>
      </NavLink>


      {/* 동호회찾기 */}
      <NavLink
        to="/clubs"
        className={({ isActive }) =>
          isActive
            ? "bottom-nav-item active"
            : "bottom-nav-item"
        }
      >
        <FiUsers className="bottom-nav-icon" />
        <span>동호회찾기</span>
      </NavLink>


      {/* 팀 매칭 */}
      <NavLink
        to="/matches"
        className={({ isActive }) =>
          isActive
            ? "bottom-nav-item active"
            : "bottom-nav-item"
        }
      >
        <FiRepeat className="bottom-nav-icon" />
        <span>팀 매칭</span>
      </NavLink>


      {/* 소통하기 */}
      <NavLink
        to="/community"
        className={({ isActive }) =>
          isActive
            ? "bottom-nav-item active"
            : "bottom-nav-item"
        }
      >
        <FiMessageCircle className="bottom-nav-icon" />
        <span>소통하기</span>
      </NavLink>


      {/* 내 정보 */}
      <NavLink
        to="/mypage"
        className={({ isActive }) =>
          isActive
            ? "bottom-nav-item active"
            : "bottom-nav-item"
        }
      >
        <FiUser className="bottom-nav-icon" />
        <span>내 정보</span>
      </NavLink>

    </nav>
  );
}

export default BottomNav;