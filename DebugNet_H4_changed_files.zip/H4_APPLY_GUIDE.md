# PlayBridge H4 적용 안내

기준 원격 커밋: `c3805c9` (`ML 챗봇 연결 성공`)

## 1. 코드 적용

프로젝트 루트에서 패치를 적용합니다.

```powershell
git apply --check ".\DebugNet_H4.patch"
git apply ".\DebugNet_H4.patch"
```

교체 파일 ZIP을 사용할 경우에는 프로젝트 루트에 압축을 풀어
동일 경로의 파일을 덮어씁니다. 패치와 ZIP은 둘 중 하나만 사용합니다.

## 2. Supabase 마이그레이션

아래 파일 전체를 Supabase SQL Editor에서 한 번 실행합니다.

```text
supabase/migrations/20260930123000_add_club_event_activity_results.sql
```

이 테이블은 일정 전 `참석/불참/미정` 의사와 실제 활동 결과를
분리해서 저장합니다.

## 3. 백엔드 확인

```powershell
Set-Location "C:\Users\Admin\mbca\2차 팀과제\앱개발\DebugNet\backend"
python -m compileall -q app main.py
python -m unittest tests.test_operator_h4
python -c "from main import app; print({path: sorted(methods) for path, methods in app.openapi()['paths'].items() if 'activity-results' in path or 'participation-risks' in path})"
```

정상 OpenAPI 결과에는 다음 세 경로가 표시됩니다.

- `GET /api/clubs/{club_id}/activity-results`
- `PUT /api/clubs/{club_id}/events/{event_id}/activity-results`
- `GET /api/clubs/{club_id}/participation-risks`

## 4. 프론트엔드 확인

```powershell
Set-Location "C:\Users\Admin\mbca\2차 팀과제\앱개발\DebugNet\frontend"
npm run build
```

앱에서 `동호회 운영자 화면 → 회원 관리 → 참여 분석`으로 이동합니다.

1. 지난 일정을 선택합니다.
2. 회원별 실제 결과를 `실제 참석 / 사전 취소 / 노쇼 / 참여 대상 아님` 중에서 선택합니다.
3. `활동 결과 저장`을 누릅니다.
4. 참여 대상 결과가 4회 이상 쌓이면 AI 위험 분석이 시작됩니다.

## 판정 주의사항

- `attendance_status`는 일정 전 참석 의사이므로 H4에 사용하지 않습니다.
- `not_eligible`은 결석과 분석 분모에서 제외됩니다.
- 데이터가 4회 미만이면 위험 판정을 내리지 않고 `분석 대기`로 표시합니다.
- 위험 지수는 이탈 확률이 아니라 운영자가 먼저 살펴볼 순서를 위한 참고 지표입니다.
